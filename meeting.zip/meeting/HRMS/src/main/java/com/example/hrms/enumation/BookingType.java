package com.example.hrms.enumation;

public enum BookingType {
    ONLY,
    WEEKLY,
    DAILY
}